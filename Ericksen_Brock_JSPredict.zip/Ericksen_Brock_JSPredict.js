function myBirthYearFunc(){
    console.log("I was born in " + 1980);
}

// I was born in 1980


function myBirthYearFunc(birthYearInput){
    console.log("I was born in " + birthYearInput);
}

// I was born in 1980


function myBirthYearFunc(birthYearInput){
    console.log("I was born in " + birthYearInput);
}

// Summing Numbers
// num1 is 10
// num2 is 20
// 30
